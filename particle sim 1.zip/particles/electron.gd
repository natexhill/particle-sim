extends CharacterBody2D

@export var particle_type = "electron"

var attraction_strength = 80000.0
var particles = []

func _physics_process(delta):
	var force = Vector2.ZERO
	
	for p in particles:
		if p != self:
			var direction = p.global_position - global_position
			var distance = direction.length()

			if distance < 1000:
				if (particle_type == "electron" and p.particle_type == "proton"):
					if distance > 100:
						force += direction.normalized() * attraction_strength / distance
					elif distance < 100:
						force -= direction.normalized() * attraction_strength / distance
						
				if particle_type == "electron" and p.particle_type == "electron":
					force -= direction.normalized() * (attraction_strength) / distance


	velocity += force * delta
	velocity *= 0.98
	move_and_slide()
