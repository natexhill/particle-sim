extends CharacterBody2D

@export var particle_type = "neutron"
var attraction_strength = 8000.0
var particles = []

func _physics_process(delta):
	var force = Vector2.ZERO
	
	for p in particles:
		if p != self:
			var direction = p.global_position - global_position
			var distance = direction.length()

			if distance < 500:

				if particle_type == "neutron" and p.particle_type == "proton":
					force += direction.normalized() * attraction_strength / distance
					
				if particle_type == "neutron" and p.particle_type == "neutron":
					force += direction.normalized() * attraction_strength / distance
	velocity += force * delta
	velocity *= 0.98
	move_and_slide()
