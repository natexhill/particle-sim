extends Node2D

@export var proton_scene: PackedScene
@export var neutron_scene: PackedScene
@export var electron_scene: PackedScene
var particles = []

func _ready():
	for i in range(10):
		var p = proton_scene.instantiate()
		p.position = Vector2(randf_range(112,1040), randf_range(112,540))
		add_child(p)
		particles.append(p)

	for i in range(15):
		var n = neutron_scene.instantiate()
		n.position = Vector2(randf_range(112,1040), randf_range(112,540))
		add_child(n)
		particles.append(n)

	for i in range(50):
		var e = electron_scene.instantiate()
		e.position = Vector2(randf_range(112,1040), randf_range(112,540))
		add_child(e)
		particles.append(e)
		
	for p in particles:
		p.particles = particles
